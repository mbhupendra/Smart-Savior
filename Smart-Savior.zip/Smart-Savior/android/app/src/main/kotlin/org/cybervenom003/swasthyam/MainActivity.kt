package org.cybervenom003.swasthyam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
